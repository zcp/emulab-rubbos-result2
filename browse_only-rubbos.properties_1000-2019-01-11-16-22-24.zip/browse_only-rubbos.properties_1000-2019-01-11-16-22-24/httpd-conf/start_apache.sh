#!/bin/bash
/usr/local/apache2/bin/apachectl -k start
sleep infinity
